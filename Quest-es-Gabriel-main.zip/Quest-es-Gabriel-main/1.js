//1
const carrinho = [];
carrinho.push("itemTop");//adiciona
carrinho.push("itemTop2");//adiciona
carrinho.pop();//remove
console.log(carrinho)