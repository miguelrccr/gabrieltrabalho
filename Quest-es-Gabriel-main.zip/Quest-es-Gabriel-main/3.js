//3
let array = ["pneu", "parafuso", "volante"];
function arra (){
    array.unshift("câmbio");
    array.pop()
};
arra();
console.log(array);